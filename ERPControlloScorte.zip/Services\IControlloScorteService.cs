using ERPControlloScorte.DTOs;
using ERPControlloScorte.Models;

namespace ERPControlloScorte.Services
{
    /// <summary>
    /// Interfaccia per il servizio di gestione scorte.
    /// Definisce tutte le operazioni disponibili per il controllo scorte.
    /// </summary>
    public interface IControlloScorteService
    {
        // --- Prodotti ---
        Task<ApiResponse<ProdottoResponse>> GetProdottoAsync(int id);
        Task<ApiResponse<ProdottoResponse>> GetProdottoByCodiceAsync(string codice);
        Task<ApiResponse<PaginatedResponse<ProdottoResponse>>> GetProdottiAsync(
            int page = 1, int pageSize = 20, string? categoria = null,
            string? ricerca = null, bool? soloSottoScortaMinima = null);
        Task<ApiResponse<ProdottoResponse>> CreaProdottoAsync(CreaProdottoRequest request);
        Task<ApiResponse<ProdottoResponse>> AggiornaProdottoAsync(int id, AggiornaProdottoRequest request);
        Task<ApiResponse<bool>> DisattivaProdottoAsync(int id);

        // --- Movimenti ---
        Task<ApiResponse<MovimentoResponse>> RegistraMovimentoAsync(RegistraMovimentoRequest request);
        Task<ApiResponse<PaginatedResponse<MovimentoResponse>>> GetMovimentiAsync(
            int? prodottoId = null, TipoMovimento? tipo = null,
            DateTime? da = null, DateTime? a = null,
            int page = 1, int pageSize = 20);
        Task<ApiResponse<MovimentoResponse>> GetMovimentoAsync(int id);

        // --- Alert ---
        Task<ApiResponse<List<AlertResponse>>> GetAlertAttiviAsync();
        Task<ApiResponse<bool>> RisolviAlertAsync(int id);
        Task<ApiResponse<PaginatedResponse<AlertResponse>>> GetStoricoAlertAsync(
            int? prodottoId = null, int page = 1, int pageSize = 20);

        // --- Dashboard ---
        Task<ApiResponse<DashboardScorteResponse>> GetDashboardAsync();

        // --- Controllo Scorte ---
        Task<ApiResponse<int>> VerificaScorteAsync();
    }
}
