using Microsoft.AspNetCore.Mvc;
using ERPControlloScorte.DTOs;
using ERPControlloScorte.Models;
using ERPControlloScorte.Services;

namespace ERPControlloScorte.Controllers
{
    /// <summary>
    /// Controller per la gestione dei movimenti di magazzino (carichi/scarichi).
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class MovimentiController : ControllerBase
    {
        private readonly IControlloScorteService _service;

        public MovimentiController(IControlloScorteService service)
        {
            _service = service;
        }

        /// <summary>
        /// Restituisce la lista paginata dei movimenti con filtri opzionali.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetMovimenti(
            [FromQuery] int? prodottoId = null,
            [FromQuery] TipoMovimento? tipo = null,
            [FromQuery] DateTime? da = null,
            [FromQuery] DateTime? a = null,
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 20)
        {
            var result = await _service.GetMovimentiAsync(prodottoId, tipo, da, a, page, pageSize);
            return result.Success ? Ok(result) : BadRequest(result);
        }

        /// <summary>
        /// Restituisce un movimento specifico tramite ID.
        /// </summary>
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetMovimento(int id)
        {
            var result = await _service.GetMovimentoAsync(id);
            return result.Success ? Ok(result) : NotFound(result);
        }

        /// <summary>
        /// Registra un nuovo movimento di magazzino (carico o scarico).
        /// Aggiorna automaticamente la quantità disponibile del prodotto.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> RegistraMovimento([FromBody] RegistraMovimentoRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var result = await _service.RegistraMovimentoAsync(request);
            if (result.Success)
                return CreatedAtAction(nameof(GetMovimento), new { id = result.Data!.Id }, result);

            return BadRequest(result);
        }
    }
}
