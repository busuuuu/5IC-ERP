using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ERPControlloScorte.Models
{
    /// <summary>
    /// Rappresenta un prodotto nel sistema ERP.
    /// Questa entità è condivisa con gli altri moduli del progetto.
    /// </summary>
    public class Prodotto
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Codice { get; set; } = string.Empty;

        [Required]
        [StringLength(200)]
        public string Nome { get; set; } = string.Empty;

        [StringLength(500)]
        public string? Descrizione { get; set; }

        [Required]
        [StringLength(50)]
        public string Categoria { get; set; } = string.Empty;

        [Required]
        [StringLength(20)]
        public string UnitaMisura { get; set; } = "pz"; // pz, kg, lt, m, ecc.

        [Column(TypeName = "decimal(18,2)")]
        public decimal PrezzoUnitario { get; set; }

        /// <summary>
        /// Quantità attuale in magazzino
        /// </summary>
        [Column(TypeName = "decimal(18,2)")]
        public decimal QuantitaDisponibile { get; set; }

        /// <summary>
        /// Soglia sotto la quale scatta l'allarme scorta minima
        /// </summary>
        [Column(TypeName = "decimal(18,2)")]
        public decimal ScortaMinima { get; set; }

        /// <summary>
        /// Quantità ideale da raggiungere con il riordino
        /// </summary>
        [Column(TypeName = "decimal(18,2)")]
        public decimal PuntoRiordino { get; set; }

        /// <summary>
        /// Indica se il prodotto è attivo nel sistema
        /// </summary>
        public bool Attivo { get; set; } = true;

        public DateTime DataCreazione { get; set; } = DateTime.UtcNow;
        public DateTime? DataUltimoAggiornamento { get; set; }

        // Navigation properties
        public ICollection<MovimentoScorta> Movimenti { get; set; } = new List<MovimentoScorta>();
    }
}
