using Microsoft.AspNetCore.Mvc;
using ERPControlloScorte.Services;

namespace ERPControlloScorte.Controllers
{
    /// <summary>
    /// Controller per la gestione degli alert di scorta minima.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class AlertController : ControllerBase
    {
        private readonly IControlloScorteService _service;

        public AlertController(IControlloScorteService service)
        {
            _service = service;
        }

        /// <summary>
        /// Restituisce tutti gli alert attivi (non risolti), ordinati per gravità.
        /// </summary>
        [HttpGet("attivi")]
        public async Task<IActionResult> GetAlertAttivi()
        {
            var result = await _service.GetAlertAttiviAsync();
            return Ok(result);
        }

        /// <summary>
        /// Restituisce lo storico paginato degli alert.
        /// </summary>
        [HttpGet("storico")]
        public async Task<IActionResult> GetStoricoAlert(
            [FromQuery] int? prodottoId = null,
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 20)
        {
            var result = await _service.GetStoricoAlertAsync(prodottoId, page, pageSize);
            return Ok(result);
        }

        /// <summary>
        /// Segna un alert come risolto.
        /// </summary>
        [HttpPut("{id:int}/risolvi")]
        public async Task<IActionResult> RisolviAlert(int id)
        {
            var result = await _service.RisolviAlertAsync(id);
            return result.Success ? Ok(result) : NotFound(result);
        }

        /// <summary>
        /// Esegue un controllo manuale di tutte le scorte e genera alert se necessario.
        /// </summary>
        [HttpPost("verifica")]
        public async Task<IActionResult> VerificaScorte()
        {
            var result = await _service.VerificaScorteAsync();
            return Ok(result);
        }
    }
}
