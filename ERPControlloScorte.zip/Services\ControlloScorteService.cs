using Microsoft.EntityFrameworkCore;
using ERPControlloScorte.Data;
using ERPControlloScorte.DTOs;
using ERPControlloScorte.Models;

namespace ERPControlloScorte.Services
{
    /// <summary>
    /// Implementazione del servizio di controllo scorte.
    /// Contiene tutta la logica di business per gestire prodotti, movimenti e alert.
    /// </summary>
    public class ControlloScorteService : IControlloScorteService
    {
        private readonly AppDbContext _context;
        private readonly ILogger<ControlloScorteService> _logger;

        public ControlloScorteService(AppDbContext context, ILogger<ControlloScorteService> logger)
        {
            _context = context;
            _logger = logger;
        }

        // ============================================================
        // PRODOTTI
        // ============================================================

        public async Task<ApiResponse<ProdottoResponse>> GetProdottoAsync(int id)
        {
            var prodotto = await _context.Prodotti.FindAsync(id);
            if (prodotto == null)
                return ApiResponse<ProdottoResponse>.Error($"Prodotto con ID {id} non trovato");

            return ApiResponse<ProdottoResponse>.Ok(MapProdottoToResponse(prodotto));
        }

        public async Task<ApiResponse<ProdottoResponse>> GetProdottoByCodiceAsync(string codice)
        {
            var prodotto = await _context.Prodotti
                .FirstOrDefaultAsync(p => p.Codice == codice);

            if (prodotto == null)
                return ApiResponse<ProdottoResponse>.Error($"Prodotto con codice '{codice}' non trovato");

            return ApiResponse<ProdottoResponse>.Ok(MapProdottoToResponse(prodotto));
        }

        public async Task<ApiResponse<PaginatedResponse<ProdottoResponse>>> GetProdottiAsync(
            int page = 1, int pageSize = 20, string? categoria = null,
            string? ricerca = null, bool? soloSottoScortaMinima = null)
        {
            var query = _context.Prodotti.Where(p => p.Attivo);

            // Filtro per categoria
            if (!string.IsNullOrWhiteSpace(categoria))
                query = query.Where(p => p.Categoria == categoria);

            // Ricerca per nome o codice
            if (!string.IsNullOrWhiteSpace(ricerca))
                query = query.Where(p => p.Nome.Contains(ricerca) || p.Codice.Contains(ricerca));

            // Filtro per prodotti sotto scorta minima
            if (soloSottoScortaMinima == true)
                query = query.Where(p => p.QuantitaDisponibile < p.ScortaMinima);

            var totalCount = await query.CountAsync();

            var items = await query
                .OrderBy(p => p.Nome)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var response = new PaginatedResponse<ProdottoResponse>
            {
                Items = items.Select(MapProdottoToResponse).ToList(),
                TotalCount = totalCount,
                Page = page,
                PageSize = pageSize
            };

            return ApiResponse<PaginatedResponse<ProdottoResponse>>.Ok(response);
        }

        public async Task<ApiResponse<ProdottoResponse>> CreaProdottoAsync(CreaProdottoRequest request)
        {
            // Verifica che il codice non esista già
            var esiste = await _context.Prodotti.AnyAsync(p => p.Codice == request.Codice);
            if (esiste)
                return ApiResponse<ProdottoResponse>.Error($"Il codice prodotto '{request.Codice}' è già in uso");

            var prodotto = new Prodotto
            {
                Codice = request.Codice,
                Nome = request.Nome,
                Descrizione = request.Descrizione,
                Categoria = request.Categoria,
                UnitaMisura = request.UnitaMisura,
                PrezzoUnitario = request.PrezzoUnitario,
                QuantitaDisponibile = request.QuantitaIniziale,
                ScortaMinima = request.ScortaMinima,
                PuntoRiordino = request.PuntoRiordino,
                DataCreazione = DateTime.UtcNow
            };

            _context.Prodotti.Add(prodotto);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Creato nuovo prodotto: {Codice} - {Nome}", prodotto.Codice, prodotto.Nome);

            // Se la quantità iniziale è sotto la scorta minima, genera un alert
            if (prodotto.QuantitaDisponibile < prodotto.ScortaMinima)
                await GeneraAlertAsync(prodotto);

            return ApiResponse<ProdottoResponse>.Ok(
                MapProdottoToResponse(prodotto),
                $"Prodotto '{prodotto.Nome}' creato con successo");
        }

        public async Task<ApiResponse<ProdottoResponse>> AggiornaProdottoAsync(int id, AggiornaProdottoRequest request)
        {
            var prodotto = await _context.Prodotti.FindAsync(id);
            if (prodotto == null)
                return ApiResponse<ProdottoResponse>.Error($"Prodotto con ID {id} non trovato");

            if (request.Nome != null) prodotto.Nome = request.Nome;
            if (request.Descrizione != null) prodotto.Descrizione = request.Descrizione;
            if (request.Categoria != null) prodotto.Categoria = request.Categoria;
            if (request.PrezzoUnitario.HasValue) prodotto.PrezzoUnitario = request.PrezzoUnitario.Value;
            if (request.ScortaMinima.HasValue) prodotto.ScortaMinima = request.ScortaMinima.Value;
            if (request.PuntoRiordino.HasValue) prodotto.PuntoRiordino = request.PuntoRiordino.Value;

            prodotto.DataUltimoAggiornamento = DateTime.UtcNow;

            await _context.SaveChangesAsync();
            _logger.LogInformation("Aggiornato prodotto: {Codice}", prodotto.Codice);

            return ApiResponse<ProdottoResponse>.Ok(
                MapProdottoToResponse(prodotto),
                $"Prodotto '{prodotto.Nome}' aggiornato con successo");
        }

        public async Task<ApiResponse<bool>> DisattivaProdottoAsync(int id)
        {
            var prodotto = await _context.Prodotti.FindAsync(id);
            if (prodotto == null)
                return ApiResponse<bool>.Error($"Prodotto con ID {id} non trovato");

            prodotto.Attivo = false;
            prodotto.DataUltimoAggiornamento = DateTime.UtcNow;
            await _context.SaveChangesAsync();

            _logger.LogInformation("Disattivato prodotto: {Codice}", prodotto.Codice);
            return ApiResponse<bool>.Ok(true, $"Prodotto '{prodotto.Nome}' disattivato");
        }

        // ============================================================
        // MOVIMENTI
        // ============================================================

        public async Task<ApiResponse<MovimentoResponse>> RegistraMovimentoAsync(RegistraMovimentoRequest request)
        {
            var prodotto = await _context.Prodotti.FindAsync(request.ProdottoId);
            if (prodotto == null)
                return ApiResponse<MovimentoResponse>.Error($"Prodotto con ID {request.ProdottoId} non trovato");

            if (!prodotto.Attivo)
                return ApiResponse<MovimentoResponse>.Error($"Il prodotto '{prodotto.Nome}' non è attivo");

            // Verifica disponibilità per scarico
            if (request.Tipo == TipoMovimento.Scarico && prodotto.QuantitaDisponibile < request.Quantita)
                return ApiResponse<MovimentoResponse>.Error(
                    $"Quantità insufficiente. Disponibile: {prodotto.QuantitaDisponibile} {prodotto.UnitaMisura}, " +
                    $"Richiesto: {request.Quantita} {prodotto.UnitaMisura}");

            // Aggiorna la quantità
            if (request.Tipo == TipoMovimento.Carico)
                prodotto.QuantitaDisponibile += request.Quantita;
            else
                prodotto.QuantitaDisponibile -= request.Quantita;

            prodotto.DataUltimoAggiornamento = DateTime.UtcNow;

            // Registra il movimento
            var movimento = new MovimentoScorta
            {
                ProdottoId = request.ProdottoId,
                Tipo = request.Tipo,
                Quantita = request.Quantita,
                Causale = request.Causale,
                RiferimentoEsterno = request.RiferimentoEsterno,
                Operatore = request.Operatore,
                DataMovimento = DateTime.UtcNow,
                QuantitaDopoMovimento = prodotto.QuantitaDisponibile
            };

            _context.MovimentiScorte.Add(movimento);
            await _context.SaveChangesAsync();

            _logger.LogInformation(
                "Movimento registrato: {Tipo} di {Quantita} {UnitaMisura} per {Codice}",
                request.Tipo, request.Quantita, prodotto.UnitaMisura, prodotto.Codice);

            // Verifica se generare un alert dopo il movimento
            await VerificaScortaSingoloProdottoAsync(prodotto);

            // Ricarica con la navigation property per la risposta
            await _context.Entry(movimento).Reference(m => m.Prodotto).LoadAsync();

            return ApiResponse<MovimentoResponse>.Ok(
                MapMovimentoToResponse(movimento),
                $"Movimento di {request.Tipo} registrato con successo");
        }

        public async Task<ApiResponse<PaginatedResponse<MovimentoResponse>>> GetMovimentiAsync(
            int? prodottoId = null, TipoMovimento? tipo = null,
            DateTime? da = null, DateTime? a = null,
            int page = 1, int pageSize = 20)
        {
            var query = _context.MovimentiScorte
                .Include(m => m.Prodotto)
                .AsQueryable();

            if (prodottoId.HasValue)
                query = query.Where(m => m.ProdottoId == prodottoId.Value);
            if (tipo.HasValue)
                query = query.Where(m => m.Tipo == tipo.Value);
            if (da.HasValue)
                query = query.Where(m => m.DataMovimento >= da.Value);
            if (a.HasValue)
                query = query.Where(m => m.DataMovimento <= a.Value);

            var totalCount = await query.CountAsync();

            var items = await query
                .OrderByDescending(m => m.DataMovimento)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var response = new PaginatedResponse<MovimentoResponse>
            {
                Items = items.Select(MapMovimentoToResponse).ToList(),
                TotalCount = totalCount,
                Page = page,
                PageSize = pageSize
            };

            return ApiResponse<PaginatedResponse<MovimentoResponse>>.Ok(response);
        }

        public async Task<ApiResponse<MovimentoResponse>> GetMovimentoAsync(int id)
        {
            var movimento = await _context.MovimentiScorte
                .Include(m => m.Prodotto)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (movimento == null)
                return ApiResponse<MovimentoResponse>.Error($"Movimento con ID {id} non trovato");

            return ApiResponse<MovimentoResponse>.Ok(MapMovimentoToResponse(movimento));
        }

        // ============================================================
        // ALERT
        // ============================================================

        public async Task<ApiResponse<List<AlertResponse>>> GetAlertAttiviAsync()
        {
            var alerts = await _context.AlertScorte
                .Include(a => a.Prodotto)
                .Where(a => !a.Risolto)
                .OrderByDescending(a => a.Livello)
                .ThenByDescending(a => a.DataCreazione)
                .ToListAsync();

            return ApiResponse<List<AlertResponse>>.Ok(
                alerts.Select(MapAlertToResponse).ToList());
        }

        public async Task<ApiResponse<bool>> RisolviAlertAsync(int id)
        {
            var alert = await _context.AlertScorte.FindAsync(id);
            if (alert == null)
                return ApiResponse<bool>.Error($"Alert con ID {id} non trovato");

            alert.Risolto = true;
            alert.DataRisoluzione = DateTime.UtcNow;
            await _context.SaveChangesAsync();

            return ApiResponse<bool>.Ok(true, "Alert risolto con successo");
        }

        public async Task<ApiResponse<PaginatedResponse<AlertResponse>>> GetStoricoAlertAsync(
            int? prodottoId = null, int page = 1, int pageSize = 20)
        {
            var query = _context.AlertScorte
                .Include(a => a.Prodotto)
                .AsQueryable();

            if (prodottoId.HasValue)
                query = query.Where(a => a.ProdottoId == prodottoId.Value);

            var totalCount = await query.CountAsync();

            var items = await query
                .OrderByDescending(a => a.DataCreazione)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var response = new PaginatedResponse<AlertResponse>
            {
                Items = items.Select(MapAlertToResponse).ToList(),
                TotalCount = totalCount,
                Page = page,
                PageSize = pageSize
            };

            return ApiResponse<PaginatedResponse<AlertResponse>>.Ok(response);
        }

        // ============================================================
        // DASHBOARD
        // ============================================================

        public async Task<ApiResponse<DashboardScorteResponse>> GetDashboardAsync()
        {
            var oggi = DateTime.UtcNow.Date;
            var inizioSettimana = oggi.AddDays(-(int)oggi.DayOfWeek);

            var prodottiAttivi = await _context.Prodotti.Where(p => p.Attivo).ToListAsync();

            var dashboard = new DashboardScorteResponse
            {
                TotaleProdotti = await _context.Prodotti.CountAsync(),
                ProdottiAttivi = prodottiAttivi.Count,
                ProdottiSottoScortaMinima = prodottiAttivi.Count(p => p.QuantitaDisponibile < p.ScortaMinima && p.QuantitaDisponibile > 0),
                ProdottiEsauriti = prodottiAttivi.Count(p => p.QuantitaDisponibile <= 0),
                AlertAttivi = await _context.AlertScorte.CountAsync(a => !a.Risolto),
                ValoreTotaleMagazzino = prodottiAttivi.Sum(p => p.QuantitaDisponibile * p.PrezzoUnitario),
                MovimentiOggi = await _context.MovimentiScorte
                    .CountAsync(m => m.DataMovimento >= oggi),
                MovimentiSettimana = await _context.MovimentiScorte
                    .CountAsync(m => m.DataMovimento >= inizioSettimana),
                ProdottiCritici = prodottiAttivi
                    .Where(p => p.QuantitaDisponibile < p.ScortaMinima)
                    .OrderBy(p => p.QuantitaDisponibile)
                    .Take(10)
                    .Select(MapProdottoToResponse)
                    .ToList(),
                UltimiAlert = await _context.AlertScorte
                    .Include(a => a.Prodotto)
                    .Where(a => !a.Risolto)
                    .OrderByDescending(a => a.DataCreazione)
                    .Take(5)
                    .Select(a => MapAlertToResponse(a))
                    .ToListAsync()
            };

            return ApiResponse<DashboardScorteResponse>.Ok(dashboard);
        }

        // ============================================================
        // CONTROLLO SCORTE (verifica automatica)
        // ============================================================

        public async Task<ApiResponse<int>> VerificaScorteAsync()
        {
            var prodottiAttivi = await _context.Prodotti
                .Where(p => p.Attivo)
                .ToListAsync();

            int alertGenerati = 0;

            foreach (var prodotto in prodottiAttivi)
            {
                if (await VerificaScortaSingoloProdottoAsync(prodotto))
                    alertGenerati++;
            }

            return ApiResponse<int>.Ok(alertGenerati,
                alertGenerati > 0
                    ? $"Verifica completata: {alertGenerati} nuovi alert generati"
                    : "Verifica completata: nessun nuovo alert");
        }

        // ============================================================
        // METODI PRIVATI
        // ============================================================

        /// <summary>
        /// Verifica la scorta di un singolo prodotto e genera alert se necessario.
        /// Ritorna true se è stato generato un nuovo alert.
        /// </summary>
        private async Task<bool> VerificaScortaSingoloProdottoAsync(Prodotto prodotto)
        {
            LivelliAlert? livello = null;
            string messaggio = string.Empty;

            if (prodotto.QuantitaDisponibile <= 0)
            {
                livello = LivelliAlert.Esaurito;
                messaggio = $"ESAURITO: Il prodotto '{prodotto.Nome}' ({prodotto.Codice}) ha scorta ZERO!";
            }
            else if (prodotto.QuantitaDisponibile < prodotto.ScortaMinima * 0.5m)
            {
                livello = LivelliAlert.Critico;
                messaggio = $"CRITICO: Il prodotto '{prodotto.Nome}' ({prodotto.Codice}) ha solo {prodotto.QuantitaDisponibile} {prodotto.UnitaMisura} " +
                           $"(minimo: {prodotto.ScortaMinima} {prodotto.UnitaMisura})";
            }
            else if (prodotto.QuantitaDisponibile < prodotto.ScortaMinima)
            {
                livello = LivelliAlert.Avviso;
                messaggio = $"AVVISO: Il prodotto '{prodotto.Nome}' ({prodotto.Codice}) è sotto la scorta minima. " +
                           $"Disponibile: {prodotto.QuantitaDisponibile} {prodotto.UnitaMisura}, Minimo: {prodotto.ScortaMinima} {prodotto.UnitaMisura}";
            }

            if (livello.HasValue)
            {
                // Controlla se esiste già un alert attivo dello stesso livello
                var alertEsistente = await _context.AlertScorte
                    .AnyAsync(a => a.ProdottoId == prodotto.Id && a.Livello == livello.Value && !a.Risolto);

                if (!alertEsistente)
                {
                    await GeneraAlertAsync(prodotto, livello.Value, messaggio);
                    return true;
                }
            }

            return false;
        }

        private async Task GeneraAlertAsync(Prodotto prodotto, LivelliAlert? livello = null, string? messaggio = null)
        {
            var alertLivello = livello ?? (prodotto.QuantitaDisponibile <= 0
                ? LivelliAlert.Esaurito
                : LivelliAlert.Avviso);

            var alertMessaggio = messaggio ??
                $"Il prodotto '{prodotto.Nome}' ({prodotto.Codice}) ha scorta {prodotto.QuantitaDisponibile} {prodotto.UnitaMisura} " +
                $"(minimo: {prodotto.ScortaMinima} {prodotto.UnitaMisura})";

            var alert = new AlertScorta
            {
                ProdottoId = prodotto.Id,
                Livello = alertLivello,
                Messaggio = alertMessaggio,
                QuantitaAttuale = prodotto.QuantitaDisponibile,
                ScortaMinima = prodotto.ScortaMinima,
                DataCreazione = DateTime.UtcNow
            };

            _context.AlertScorte.Add(alert);
            await _context.SaveChangesAsync();

            _logger.LogWarning("Alert scorta generato: [{Livello}] {Messaggio}",
                alertLivello, alertMessaggio);
        }

        // ============================================================
        // MAPPING
        // ============================================================

        private static ProdottoResponse MapProdottoToResponse(Prodotto p)
        {
            string statoScorta;
            if (p.QuantitaDisponibile <= 0)
                statoScorta = "Esaurito";
            else if (p.QuantitaDisponibile < p.ScortaMinima * 0.5m)
                statoScorta = "Critico";
            else if (p.QuantitaDisponibile < p.ScortaMinima)
                statoScorta = "Basso";
            else
                statoScorta = "OK";

            return new ProdottoResponse
            {
                Id = p.Id,
                Codice = p.Codice,
                Nome = p.Nome,
                Descrizione = p.Descrizione,
                Categoria = p.Categoria,
                UnitaMisura = p.UnitaMisura,
                PrezzoUnitario = p.PrezzoUnitario,
                QuantitaDisponibile = p.QuantitaDisponibile,
                ScortaMinima = p.ScortaMinima,
                PuntoRiordino = p.PuntoRiordino,
                Attivo = p.Attivo,
                StatoScorta = statoScorta,
                DataCreazione = p.DataCreazione,
                DataUltimoAggiornamento = p.DataUltimoAggiornamento
            };
        }

        private static MovimentoResponse MapMovimentoToResponse(MovimentoScorta m)
        {
            return new MovimentoResponse
            {
                Id = m.Id,
                ProdottoId = m.ProdottoId,
                CodiceProdotto = m.Prodotto?.Codice ?? "",
                NomeProdotto = m.Prodotto?.Nome ?? "",
                Tipo = m.Tipo.ToString(),
                Quantita = m.Quantita,
                Causale = m.Causale,
                RiferimentoEsterno = m.RiferimentoEsterno,
                Operatore = m.Operatore,
                DataMovimento = m.DataMovimento,
                QuantitaDopoMovimento = m.QuantitaDopoMovimento
            };
        }

        private static AlertResponse MapAlertToResponse(AlertScorta a)
        {
            return new AlertResponse
            {
                Id = a.Id,
                ProdottoId = a.ProdottoId,
                CodiceProdotto = a.Prodotto?.Codice ?? "",
                NomeProdotto = a.Prodotto?.Nome ?? "",
                Livello = a.Livello.ToString(),
                Messaggio = a.Messaggio,
                QuantitaAttuale = a.QuantitaAttuale,
                ScortaMinima = a.ScortaMinima,
                Risolto = a.Risolto,
                DataCreazione = a.DataCreazione,
                DataRisoluzione = a.DataRisoluzione
            };
        }
    }
}
