using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ERPControlloScorte.Models
{
    /// <summary>
    /// Tipo di movimento di scorta: Carico (ingresso) o Scarico (uscita)
    /// </summary>
    public enum TipoMovimento
    {
        Carico = 1,   // Ingresso merce in magazzino
        Scarico = 2   // Uscita merce dal magazzino
    }

    /// <summary>
    /// Rappresenta un movimento di magazzino (carico/scarico).
    /// Ogni movimento modifica la quantità disponibile di un prodotto.
    /// </summary>
    public class MovimentoScorta
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int ProdottoId { get; set; }

        [Required]
        public TipoMovimento Tipo { get; set; }

        /// <summary>
        /// Quantità movimentata (sempre positiva, il tipo indica la direzione)
        /// </summary>
        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Quantita { get; set; }

        /// <summary>
        /// Motivo o descrizione del movimento (es. "Ordine cliente #123", "Rifornimento fornitore X")
        /// </summary>
        [StringLength(500)]
        public string? Causale { get; set; }

        /// <summary>
        /// Riferimento esterno (es. numero ordine, DDT, ecc.)
        /// </summary>
        [StringLength(100)]
        public string? RiferimentoEsterno { get; set; }

        /// <summary>
        /// Utente che ha registrato il movimento
        /// </summary>
        [StringLength(100)]
        public string? Operatore { get; set; }

        public DateTime DataMovimento { get; set; } = DateTime.UtcNow;

        /// <summary>
        /// Quantità disponibile del prodotto DOPO il movimento
        /// </summary>
        [Column(TypeName = "decimal(18,2)")]
        public decimal QuantitaDopoMovimento { get; set; }

        // Navigation property
        [ForeignKey("ProdottoId")]
        public Prodotto? Prodotto { get; set; }
    }
}
