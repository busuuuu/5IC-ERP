using Microsoft.AspNetCore.Mvc;
using ERPControlloScorte.DTOs;
using ERPControlloScorte.Services;

namespace ERPControlloScorte.Controllers
{
    /// <summary>
    /// Controller per la gestione dei prodotti nel sistema di controllo scorte.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class ProdottiController : ControllerBase
    {
        private readonly IControlloScorteService _service;

        public ProdottiController(IControlloScorteService service)
        {
            _service = service;
        }

        /// <summary>
        /// Restituisce la lista paginata dei prodotti con filtri opzionali.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetProdotti(
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 20,
            [FromQuery] string? categoria = null,
            [FromQuery] string? ricerca = null,
            [FromQuery] bool? soloSottoScortaMinima = null)
        {
            var result = await _service.GetProdottiAsync(page, pageSize, categoria, ricerca, soloSottoScortaMinima);
            return result.Success ? Ok(result) : BadRequest(result);
        }

        /// <summary>
        /// Restituisce un prodotto specifico tramite ID.
        /// </summary>
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetProdotto(int id)
        {
            var result = await _service.GetProdottoAsync(id);
            return result.Success ? Ok(result) : NotFound(result);
        }

        /// <summary>
        /// Restituisce un prodotto specifico tramite codice.
        /// </summary>
        [HttpGet("codice/{codice}")]
        public async Task<IActionResult> GetProdottoByCodice(string codice)
        {
            var result = await _service.GetProdottoByCodiceAsync(codice);
            return result.Success ? Ok(result) : NotFound(result);
        }

        /// <summary>
        /// Crea un nuovo prodotto nel sistema.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> CreaProdotto([FromBody] CreaProdottoRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var result = await _service.CreaProdottoAsync(request);
            if (result.Success)
                return CreatedAtAction(nameof(GetProdotto), new { id = result.Data!.Id }, result);

            return BadRequest(result);
        }

        /// <summary>
        /// Aggiorna un prodotto esistente.
        /// </summary>
        [HttpPut("{id:int}")]
        public async Task<IActionResult> AggiornaProdotto(int id, [FromBody] AggiornaProdottoRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var result = await _service.AggiornaProdottoAsync(id, request);
            return result.Success ? Ok(result) : NotFound(result);
        }

        /// <summary>
        /// Disattiva (soft delete) un prodotto.
        /// </summary>
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DisattivaProdotto(int id)
        {
            var result = await _service.DisattivaProdottoAsync(id);
            return result.Success ? Ok(result) : NotFound(result);
        }
    }
}
