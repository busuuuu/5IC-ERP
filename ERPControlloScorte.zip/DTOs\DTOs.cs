using System.ComponentModel.DataAnnotations;
using ERPControlloScorte.Models;

namespace ERPControlloScorte.DTOs
{
    // ============================================================
    // DTOs per Prodotto
    // ============================================================

    /// <summary>
    /// DTO per la creazione di un nuovo prodotto
    /// </summary>
    public class CreaProdottoRequest
    {
        [Required(ErrorMessage = "Il codice prodotto è obbligatorio")]
        [StringLength(50)]
        public string Codice { get; set; } = string.Empty;

        [Required(ErrorMessage = "Il nome prodotto è obbligatorio")]
        [StringLength(200)]
        public string Nome { get; set; } = string.Empty;

        [StringLength(500)]
        public string? Descrizione { get; set; }

        [Required(ErrorMessage = "La categoria è obbligatoria")]
        [StringLength(50)]
        public string Categoria { get; set; } = string.Empty;

        [StringLength(20)]
        public string UnitaMisura { get; set; } = "pz";

        [Range(0, double.MaxValue, ErrorMessage = "Il prezzo deve essere positivo")]
        public decimal PrezzoUnitario { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "La quantità deve essere positiva")]
        public decimal QuantitaIniziale { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "La scorta minima deve essere positiva")]
        public decimal ScortaMinima { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "Il punto di riordino deve essere positivo")]
        public decimal PuntoRiordino { get; set; }
    }

    /// <summary>
    /// DTO per l'aggiornamento di un prodotto
    /// </summary>
    public class AggiornaProdottoRequest
    {
        [StringLength(200)]
        public string? Nome { get; set; }

        [StringLength(500)]
        public string? Descrizione { get; set; }

        [StringLength(50)]
        public string? Categoria { get; set; }

        [Range(0, double.MaxValue)]
        public decimal? PrezzoUnitario { get; set; }

        [Range(0, double.MaxValue)]
        public decimal? ScortaMinima { get; set; }

        [Range(0, double.MaxValue)]
        public decimal? PuntoRiordino { get; set; }
    }

    /// <summary>
    /// DTO di risposta per un prodotto con info sullo stato scorta
    /// </summary>
    public class ProdottoResponse
    {
        public int Id { get; set; }
        public string Codice { get; set; } = string.Empty;
        public string Nome { get; set; } = string.Empty;
        public string? Descrizione { get; set; }
        public string Categoria { get; set; } = string.Empty;
        public string UnitaMisura { get; set; } = string.Empty;
        public decimal PrezzoUnitario { get; set; }
        public decimal QuantitaDisponibile { get; set; }
        public decimal ScortaMinima { get; set; }
        public decimal PuntoRiordino { get; set; }
        public bool Attivo { get; set; }
        public string StatoScorta { get; set; } = string.Empty; // "OK", "Basso", "Critico", "Esaurito"
        public DateTime DataCreazione { get; set; }
        public DateTime? DataUltimoAggiornamento { get; set; }
    }

    // ============================================================
    // DTOs per Movimenti
    // ============================================================

    /// <summary>
    /// DTO per registrare un nuovo movimento di magazzino
    /// </summary>
    public class RegistraMovimentoRequest
    {
        [Required(ErrorMessage = "L'ID prodotto è obbligatorio")]
        public int ProdottoId { get; set; }

        [Required(ErrorMessage = "Il tipo movimento è obbligatorio")]
        public TipoMovimento Tipo { get; set; }

        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "La quantità deve essere maggiore di zero")]
        public decimal Quantita { get; set; }

        [StringLength(500)]
        public string? Causale { get; set; }

        [StringLength(100)]
        public string? RiferimentoEsterno { get; set; }

        [StringLength(100)]
        public string? Operatore { get; set; }
    }

    /// <summary>
    /// DTO di risposta per un movimento
    /// </summary>
    public class MovimentoResponse
    {
        public int Id { get; set; }
        public int ProdottoId { get; set; }
        public string CodiceProdotto { get; set; } = string.Empty;
        public string NomeProdotto { get; set; } = string.Empty;
        public string Tipo { get; set; } = string.Empty;
        public decimal Quantita { get; set; }
        public string? Causale { get; set; }
        public string? RiferimentoEsterno { get; set; }
        public string? Operatore { get; set; }
        public DateTime DataMovimento { get; set; }
        public decimal QuantitaDopoMovimento { get; set; }
    }

    // ============================================================
    // DTOs per Alert
    // ============================================================

    /// <summary>
    /// DTO di risposta per un alert di scorta
    /// </summary>
    public class AlertResponse
    {
        public int Id { get; set; }
        public int ProdottoId { get; set; }
        public string CodiceProdotto { get; set; } = string.Empty;
        public string NomeProdotto { get; set; } = string.Empty;
        public string Livello { get; set; } = string.Empty;
        public string Messaggio { get; set; } = string.Empty;
        public decimal QuantitaAttuale { get; set; }
        public decimal ScortaMinima { get; set; }
        public bool Risolto { get; set; }
        public DateTime DataCreazione { get; set; }
        public DateTime? DataRisoluzione { get; set; }
    }

    // ============================================================
    // DTOs per Dashboard / Riepilogo
    // ============================================================

    /// <summary>
    /// DTO per la dashboard riepilogativa del controllo scorte
    /// </summary>
    public class DashboardScorteResponse
    {
        public int TotaleProdotti { get; set; }
        public int ProdottiAttivi { get; set; }
        public int ProdottiSottoScortaMinima { get; set; }
        public int ProdottiEsauriti { get; set; }
        public int AlertAttivi { get; set; }
        public decimal ValoreTotaleMagazzino { get; set; }
        public int MovimentiOggi { get; set; }
        public int MovimentiSettimana { get; set; }
        public List<ProdottoResponse> ProdottiCritici { get; set; } = new();
        public List<AlertResponse> UltimiAlert { get; set; } = new();
    }

    // ============================================================
    // DTOs generici
    // ============================================================

    /// <summary>
    /// Risposta paginata generica
    /// </summary>
    public class PaginatedResponse<T>
    {
        public List<T> Items { get; set; } = new();
        public int TotalCount { get; set; }
        public int Page { get; set; }
        public int PageSize { get; set; }
        public int TotalPages => (int)Math.Ceiling((double)TotalCount / PageSize);
    }

    /// <summary>
    /// Risposta API standard
    /// </summary>
    public class ApiResponse<T>
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public T? Data { get; set; }

        public static ApiResponse<T> Ok(T data, string message = "Operazione completata con successo")
            => new() { Success = true, Data = data, Message = message };

        public static ApiResponse<T> Error(string message)
            => new() { Success = false, Message = message };
    }
}
