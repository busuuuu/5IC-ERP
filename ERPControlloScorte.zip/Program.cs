using Microsoft.EntityFrameworkCore;
using ERPControlloScorte.Data;
using ERPControlloScorte.Services;

var builder = WebApplication.CreateBuilder(args);

// ============================================================
// Configurazione servizi
// ============================================================

// Entity Framework Core - Database SQL Server
// NOTA: Modifica la connection string in appsettings.json per collegarti
// al database condiviso con gli altri moduli ERP del tuo team.
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        sqlOptions => sqlOptions.EnableRetryOnFailure(3)
    ));

// Registrazione servizi
builder.Services.AddScoped<IControlloScorteService, ControlloScorteService>();

// Controller
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
        options.JsonSerializerOptions.WriteIndented = true;
    });

// Swagger/OpenAPI per documentazione e testing
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "ERP Controllo Scorte API",
        Version = "v1",
        Description = "API per il modulo di Controllo Scorte del sistema ERP. " +
                      "Gestisce prodotti, movimenti di magazzino (carichi/scarichi), " +
                      "alert per scorta minima e dashboard riepilogativa.",
        Contact = new Microsoft.OpenApi.Models.OpenApiContact
        {
            Name = "Team ERP - Modulo Controllo Scorte"
        }
    });
});

// CORS - Permette chiamate da altri moduli/frontend
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

// ============================================================
// Pipeline HTTP
// ============================================================

// Swagger sempre disponibile (in produzione puoi commentare queste righe)
app.UseSwagger();
app.UseSwaggerUI(options =>
{
    options.SwaggerEndpoint("/swagger/v1/swagger.json", "ERP Controllo Scorte API v1");
    options.RoutePrefix = string.Empty; // Swagger sulla root /
});

app.UseCors("AllowAll");
app.UseAuthorization();
app.MapControllers();

// ============================================================
// Inizializzazione database
// ============================================================

// Crea il database automaticamente se non esiste (utile per sviluppo)
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    try
    {
        context.Database.EnsureCreated();
        Console.WriteLine("✅ Database inizializzato con successo!");
    }
    catch (Exception ex)
    {
        Console.WriteLine($"⚠️ Errore connessione database: {ex.Message}");
        Console.WriteLine("Assicurati che la connection string in appsettings.json sia corretta.");
    }
}

Console.WriteLine("🚀 ERP Controllo Scorte API avviata!");
Console.WriteLine("📖 Documentazione Swagger: http://localhost:5000");

app.Run();
