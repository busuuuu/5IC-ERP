using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ERPControlloScorte.Models
{
    /// <summary>
    /// Livello di gravità dell'alert
    /// </summary>
    public enum LivelliAlert
    {
        Info = 0,
        Avviso = 1,      // Scorta vicina al minimo
        Critico = 2,     // Scorta sotto il minimo
        Esaurito = 3     // Scorta a zero
    }

    /// <summary>
    /// Rappresenta un'allerta generata quando la scorta di un prodotto
    /// scende sotto la soglia minima o raggiunge zero.
    /// </summary>
    public class AlertScorta
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int ProdottoId { get; set; }

        [Required]
        public LivelliAlert Livello { get; set; }

        [Required]
        [StringLength(500)]
        public string Messaggio { get; set; } = string.Empty;

        [Column(TypeName = "decimal(18,2)")]
        public decimal QuantitaAttuale { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal ScortaMinima { get; set; }

        public DateTime DataCreazione { get; set; } = DateTime.UtcNow;

        /// <summary>
        /// Indica se l'alert è stato preso in carico/risolto
        /// </summary>
        public bool Risolto { get; set; } = false;

        public DateTime? DataRisoluzione { get; set; }

        // Navigation property
        [ForeignKey("ProdottoId")]
        public Prodotto? Prodotto { get; set; }
    }
}
