# 📦 ERP - Modulo Controllo Scorte

Modulo ASP.NET Core Web API per il **Controllo Scorte** del sistema ERP di classe.

## 🏗️ Struttura del Progetto

```
ERPControlloScorte/
├── Controllers/             # API endpoints REST
│   ├── ProdottiController.cs    # CRUD prodotti
│   ├── MovimentiController.cs   # Registrazione carichi/scarichi
│   ├── AlertController.cs       # Alert scorta minima
│   └── DashboardController.cs   # Dashboard riepilogativa
├── Models/                  # Entità del database
│   ├── Prodotto.cs              # Prodotto con scorte
│   ├── MovimentoScorta.cs       # Movimenti magazzino
│   └── AlertScorta.cs           # Alert automatici
├── DTOs/                    # Data Transfer Objects
│   └── DTOs.cs                  # Request/Response DTOs
├── Data/                    # Accesso dati
│   └── AppDbContext.cs          # Entity Framework DbContext
├── Services/                # Logica di business
│   ├── IControlloScorteService.cs   # Interfaccia
│   └── ControlloScorteService.cs    # Implementazione
├── Program.cs               # Entry point e configurazione
├── appsettings.json         # Configurazione (connection string)
└── README.md                # Questo file
```

## 🚀 Come Avviare

### Prerequisiti
- .NET 8.0 SDK
- SQL Server (o SQL Server Express / LocalDB)

### 1. Configura il Database
Modifica la **connection string** in `appsettings.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=NOME_SERVER;Database=ERP_DB;Trusted_Connection=true;TrustServerCertificate=true"
  }
}
```

> ⚠️ **IMPORTANTE**: Chiedi ai compagni che gestiscono il database il nome del server e del database da usare!

### 2. Avvia il progetto
```bash
dotnet run
```

### 3. Apri Swagger
Vai su [http://localhost:5000](http://localhost:5000) per la documentazione interattiva delle API.

## 📋 API Endpoints

### Prodotti (`/api/prodotti`)
| Metodo | Endpoint | Descrizione |
|--------|----------|-------------|
| GET | `/api/prodotti` | Lista prodotti (paginata, con filtri) |
| GET | `/api/prodotti/{id}` | Dettaglio prodotto per ID |
| GET | `/api/prodotti/codice/{codice}` | Dettaglio prodotto per codice |
| POST | `/api/prodotti` | Crea nuovo prodotto |
| PUT | `/api/prodotti/{id}` | Aggiorna prodotto |
| DELETE | `/api/prodotti/{id}` | Disattiva prodotto |

### Movimenti (`/api/movimenti`)
| Metodo | Endpoint | Descrizione |
|--------|----------|-------------|
| GET | `/api/movimenti` | Lista movimenti (paginata, con filtri) |
| GET | `/api/movimenti/{id}` | Dettaglio movimento |
| POST | `/api/movimenti` | Registra carico/scarico |

### Alert (`/api/alert`)
| Metodo | Endpoint | Descrizione |
|--------|----------|-------------|
| GET | `/api/alert/attivi` | Alert attivi (non risolti) |
| GET | `/api/alert/storico` | Storico alert |
| PUT | `/api/alert/{id}/risolvi` | Segna alert come risolto |
| POST | `/api/alert/verifica` | Verifica manuale scorte |

### Dashboard (`/api/dashboard`)
| Metodo | Endpoint | Descrizione |
|--------|----------|-------------|
| GET | `/api/dashboard` | Riepilogo completo scorte |

## 📝 Esempi di Utilizzo

### Creare un prodotto
```json
POST /api/prodotti
{
  "codice": "MAT-010",
  "nome": "Viti autofilettanti 4x30",
  "descrizione": "Viti autofilettanti in acciaio, 4x30mm",
  "categoria": "Ferramenta",
  "unitaMisura": "pz",
  "prezzoUnitario": 0.05,
  "quantitaIniziale": 10000,
  "scortaMinima": 1000,
  "puntoRiordino": 5000
}
```

### Registrare un carico (ingresso merce)
```json
POST /api/movimenti
{
  "prodottoId": 1,
  "tipo": 1,
  "quantita": 500,
  "causale": "Rifornimento da fornitore ABC",
  "riferimentoEsterno": "DDT-2024-0456",
  "operatore": "Mario Rossi"
}
```

### Registrare uno scarico (uscita merce)
```json
POST /api/movimenti
{
  "prodottoId": 1,
  "tipo": 2,
  "quantita": 200,
  "causale": "Prelievo per ordine produzione #789",
  "riferimentoEsterno": "OP-2024-789",
  "operatore": "Luigi Bianchi"
}
```

## 🔗 Integrazione con gli altri moduli

Questo modulo espone API REST che possono essere chiamate dagli altri moduli ERP:

- **Modulo Acquisti**: Può chiamare `POST /api/movimenti` con tipo `Carico` quando arriva merce.
- **Modulo Vendite**: Può chiamare `POST /api/movimenti` con tipo `Scarico` quando viene evasa un ordine.
- **Modulo Produzione**: Può consultare `GET /api/prodotti` per verificare disponibilità materiali.
- **Dashboard ERP**: Può usare `GET /api/dashboard` per mostrare lo stato delle scorte.

## ⚙️ Tecnologie Utilizzate

- **ASP.NET Core 8.0** - Framework web
- **Entity Framework Core 8.0** - ORM per accesso dati
- **SQL Server** - Database
- **Swagger/OpenAPI** - Documentazione API interattiva
