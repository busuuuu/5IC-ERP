using Microsoft.AspNetCore.Mvc;
using ERPControlloScorte.Services;

namespace ERPControlloScorte.Controllers
{
    /// <summary>
    /// Controller per la dashboard riepilogativa del controllo scorte.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class DashboardController : ControllerBase
    {
        private readonly IControlloScorteService _service;

        public DashboardController(IControlloScorteService service)
        {
            _service = service;
        }

        /// <summary>
        /// Restituisce i dati riepiogativi per la dashboard del controllo scorte.
        /// Include: totali, prodotti critici, valore magazzino, ultimi alert.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetDashboard()
        {
            var result = await _service.GetDashboardAsync();
            return Ok(result);
        }
    }
}
