using Microsoft.EntityFrameworkCore;
using ERPControlloScorte.Models;

namespace ERPControlloScorte.Data
{
    /// <summary>
    /// Contesto del database per il modulo Controllo Scorte.
    /// La connection string va configurata in appsettings.json per collegarsi
    /// al database condiviso con gli altri moduli ERP.
    /// </summary>
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Prodotto> Prodotti { get; set; }
        public DbSet<MovimentoScorta> MovimentiScorte { get; set; }
        public DbSet<AlertScorta> AlertScorte { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configurazione Prodotto
            modelBuilder.Entity<Prodotto>(entity =>
            {
                entity.ToTable("Prodotti");
                entity.HasIndex(p => p.Codice).IsUnique();
                entity.Property(p => p.Codice).IsRequired();
                entity.Property(p => p.Nome).IsRequired();
            });

            // Configurazione MovimentoScorta
            modelBuilder.Entity<MovimentoScorta>(entity =>
            {
                entity.ToTable("MovimentiScorte");
                entity.HasIndex(m => m.DataMovimento);
                entity.HasIndex(m => m.ProdottoId);

                entity.HasOne(m => m.Prodotto)
                      .WithMany(p => p.Movimenti)
                      .HasForeignKey(m => m.ProdottoId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            // Configurazione AlertScorta
            modelBuilder.Entity<AlertScorta>(entity =>
            {
                entity.ToTable("AlertScorte");
                entity.HasIndex(a => a.ProdottoId);
                entity.HasIndex(a => a.Risolto);

                entity.HasOne(a => a.Prodotto)
                      .WithMany()
                      .HasForeignKey(a => a.ProdottoId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            // Dati di seed per testing
            SeedData(modelBuilder);
        }

        /// <summary>
        /// Inserisce dati di esempio per facilitare il testing iniziale
        /// </summary>
        private void SeedData(ModelBuilder modelBuilder)
        {
            var now = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc);

            modelBuilder.Entity<Prodotto>().HasData(
                new Prodotto
                {
                    Id = 1,
                    Codice = "MAT-001",
                    Nome = "Bulloni M8x30",
                    Descrizione = "Bulloni in acciaio zincato M8x30mm",
                    Categoria = "Ferramenta",
                    UnitaMisura = "pz",
                    PrezzoUnitario = 0.15m,
                    QuantitaDisponibile = 5000,
                    ScortaMinima = 500,
                    PuntoRiordino = 2000,
                    Attivo = true,
                    DataCreazione = now
                },
                new Prodotto
                {
                    Id = 2,
                    Codice = "MAT-002",
                    Nome = "Lamiera acciaio 2mm",
                    Descrizione = "Lamiera in acciaio inox AISI 304, spessore 2mm, foglio 1x2m",
                    Categoria = "Lamiere",
                    UnitaMisura = "pz",
                    PrezzoUnitario = 85.00m,
                    QuantitaDisponibile = 12,
                    ScortaMinima = 5,
                    PuntoRiordino = 20,
                    Attivo = true,
                    DataCreazione = now
                },
                new Prodotto
                {
                    Id = 3,
                    Codice = "MAT-003",
                    Nome = "Olio lubrificante industriale",
                    Descrizione = "Olio lubrificante per macchinari industriali, fusto da 20 litri",
                    Categoria = "Lubrificanti",
                    UnitaMisura = "lt",
                    PrezzoUnitario = 4.50m,
                    QuantitaDisponibile = 80,
                    ScortaMinima = 40,
                    PuntoRiordino = 100,
                    Attivo = true,
                    DataCreazione = now
                },
                new Prodotto
                {
                    Id = 4,
                    Codice = "MAT-004",
                    Nome = "Guarnizioni in gomma",
                    Descrizione = "Guarnizioni O-ring in gomma NBR, diametro 25mm",
                    Categoria = "Guarnizioni",
                    UnitaMisura = "pz",
                    PrezzoUnitario = 0.80m,
                    QuantitaDisponibile = 50,
                    ScortaMinima = 100,
                    PuntoRiordino = 500,
                    Attivo = true,
                    DataCreazione = now
                },
                new Prodotto
                {
                    Id = 5,
                    Codice = "MAT-005",
                    Nome = "Vernice protettiva RAL 7035",
                    Descrizione = "Vernice protettiva antiruggine, colore grigio chiaro RAL 7035",
                    Categoria = "Vernici",
                    UnitaMisura = "lt",
                    PrezzoUnitario = 12.00m,
                    QuantitaDisponibile = 0,
                    ScortaMinima = 10,
                    PuntoRiordino = 30,
                    Attivo = true,
                    DataCreazione = now
                }
            );
        }
    }
}
